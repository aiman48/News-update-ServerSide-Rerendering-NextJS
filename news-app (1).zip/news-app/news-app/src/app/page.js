import NewsApp from './components/Newsapp';

const Page = async ({ searchParams }) => {
  const category = searchParams.category || 'pakistan';
  const apiUrl = `${process.env.BASE_URL}/api/news?category=${category}`;

  const news = await fetch(apiUrl, { cache: 'no-store' })
    .then(res => res.json())
    .catch(() => []);

  return <NewsApp initialNews={news} initialCategory={category} />;
};

export default Page;