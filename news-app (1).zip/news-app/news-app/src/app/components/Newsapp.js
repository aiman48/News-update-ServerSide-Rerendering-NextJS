'use client';
import { useRouter, useSearchParams } from 'next/navigation';

const categories = ["business", "entertainment", "health", "science", "sports", "technology"];

const NewsApp = ({ initialNews, initialCategory }) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentCategory = searchParams.get('category') || initialCategory;

  const handleCategoryClick = (category) => {
    router.push(`/?category=${category}`);
  };

  return (
    <div className="news-app">
      {/* Navigation Bar */}
      <nav className="nav-bar">
        <h1>Trendy News</h1>
        <div className="category-buttons">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => handleCategoryClick(category)}
              className={currentCategory === category ? 'active' : ''}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </nav>

      {/* News Grid */}
      <div className="news-grid">
        {initialNews.map((article, index) => (
          <div key={index} className="news-card">
            {article.urlToImage && (
              <img 
                src={article.urlToImage} 
                alt={article.title}
                className="news-image"
              />
            )}
            <div className="news-content">
              <h3>{article.title}</h3>
              <p>{article.description?.slice(0, 100)}...</p>
              <a href={article.url} target="_blank" className="read-more">
                Read Full Article
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NewsApp;