import Link from "next/link";

export const Card = ({ title, description, image, url }) => {
  const articleSlug = encodeURIComponent(title);
  
  return (
    <div className="card">
      {image ? (
        <img src={image} alt={title} loading="lazy" />
      ) : (
        <div className="placeholder">No Image Available</div>
      )}

      <div className="content">
        <h2 className="title">{title}</h2>
        <p>{description?.slice(0, 150)}...</p>
        
        <div className="card-footer">
          <Link href={`/article/${articleSlug}`} className="read-more">
            Read More
          </Link>
        </div>
      </div>
    </div>
  );
};