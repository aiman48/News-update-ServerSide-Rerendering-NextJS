export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category') || 'pakistan';

  try {
    const apiUrl = `https://newsapi.org/v2/top-headlines?category=${category}&country=us&apiKey=${process.env.NEWS_API_KEY}`;
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      return new Response(JSON.stringify({ error: 'Failed to fetch news' }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    return new Response(JSON.stringify(data.articles || []), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: 'Server error' }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}